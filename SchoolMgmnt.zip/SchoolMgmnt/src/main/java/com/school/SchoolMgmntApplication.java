package com.school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolMgmntApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolMgmntApplication.class, args);
	}

}
