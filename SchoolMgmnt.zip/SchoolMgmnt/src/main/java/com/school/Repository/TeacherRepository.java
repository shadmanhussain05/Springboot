package com.school.Repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.school.Entities.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Long>{
	Optional<Teacher> findByusername(String username);

}
