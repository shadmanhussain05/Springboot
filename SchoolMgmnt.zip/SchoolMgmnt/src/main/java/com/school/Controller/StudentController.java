package com.school.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	@GetMapping("/student/dashboard")
    public String studentDashboard() {
        return "student/dashboard";
    }
}
