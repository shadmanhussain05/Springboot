package com.school.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.school.Entities.Teacher;
import com.school.Repository.TeacherRepository;

@Service
public class TeacherDetailsService implements UserDetailsService {

	@Autowired
    private TeacherRepository teacherRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Teacher teacher = teacherRepository.findByusername(username)
            .orElseThrow(() -> new UsernameNotFoundException("Teacher not found: " + username));

        return User.builder()
            .username(teacher.getUsername())
            .password(teacher.getPassword())
            .roles("TEACHER")
            .build();
    }
}
