package com.school.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.school.Entities.Student;
import com.school.Repository.StudentRepository;
import com.school.Repository.TeacherRepository;

@Service
public class StudentDetailsService implements UserDetailsService {

	@Autowired
    private StudentRepository studentRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Student student = studentRepository.findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("Student not found: " + username));

        return User.builder()
            .username(student.getUsername())
            .password(student.getPassword())
            .roles("STUDENT")
            .build();
    }
}

