package com.school;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolMgmntApplicationTests {

	@Test
	void contextLoads() {
	}

}
